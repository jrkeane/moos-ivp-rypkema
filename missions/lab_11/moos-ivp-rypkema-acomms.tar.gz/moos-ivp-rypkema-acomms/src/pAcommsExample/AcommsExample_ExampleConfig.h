/************************************************************/
/*    NAME: Toby Schneider                                  */
/*    ORGN: MIT                                             */
/*    FILE: AcommsExample_ExampleConfig.h                   */
/*    DATE: 2012-03-12                                      */
/************************************************************/

#ifndef AcommsExample_EXAMPLE_CONFIG_HEADER
#define AcommsExample_EXAMPLE_CONFIG_HEADER

void showExampleConfig();

#endif

