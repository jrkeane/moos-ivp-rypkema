#!/bin/bash 

rm -rf   MOOSLog_*
rm -f    *~
rm -f    *.moos++
rm -f    .LastOpenedMOOSLogDirectory
